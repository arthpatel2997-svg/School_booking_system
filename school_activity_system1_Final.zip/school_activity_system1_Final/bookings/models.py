from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Activity(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    capacity = models.PositiveIntegerField(default=20)
    price = models.DecimalField(max_digits=6, decimal_places=2, default=0.00)

    def spots_left(self):
        bookings_count = self.bookings.filter(cancelled=False).count()
        return max(0, self.capacity - bookings_count)

    def __str__(self):
        return f"{self.title} on {self.date}"

class Booking(models.Model):
    activity = models.ForeignKey(Activity, on_delete=models.CASCADE, related_name='bookings')
    parent = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bookings')
    child_name = models.CharField(max_length=100)
    booked_at = models.DateTimeField(default=timezone.now)
    cancelled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.child_name} booked {self.activity.title} by {self.parent.username}"
