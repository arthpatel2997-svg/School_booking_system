from django import forms
from .models import Booking

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['child_name']
        widgets = {
            'child_name': forms.TextInput(attrs={'placeholder': "Child's full name", 'class': 'form-control'}),
        }
