from django.urls import path
from . import views

app_name = 'bookings'

urlpatterns = [
    path('', views.activity_list, name='activity_list'),
    path('accounts/login/', views.user_login, name='login'),
    path('accounts/logout/', views.user_logout, name='logout'),
    path('accounts/register/', views.register, name='register'),
    path('activity/<int:activity_id>/book/', views.book_activity, name='book_activity'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('booking/<int:booking_id>/cancel/', views.cancel_booking, name='cancel_booking'),
    path('invoice/', views.invoice_view, name='invoice'),
    path('invoice/pdf/', views.invoice_pdf, name='invoice_pdf'),
]
