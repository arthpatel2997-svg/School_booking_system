from django.shortcuts import render, get_object_or_404, redirect
from .models import Activity, Booking
from .forms import BookingForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.db import IntegrityError
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.http import HttpResponse
from reportlab.pdfgen import canvas



def user_login(request):
    if request.user.is_authenticated:
        return redirect('bookings:activity_list')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('bookings:activity_list')
    else:
        form = AuthenticationForm()
    return render(request, 'bookings/login.html', {'form': form})

def register(request):
    if request.user.is_authenticated:
        return redirect('bookings:activity_list')

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, "Account created successfully. You can now log in.")
            return redirect('bookings:login')
    else:
        form = UserCreationForm()

    return render(request, 'bookings/register.html', {'form': form})


def user_logout(request):
    logout(request)
    return redirect('bookings:activity_list')

def activity_list(request):
    activities = Activity.objects.order_by('date', 'start_time')
    return render(request, 'bookings/activity_list.html', {'activities': activities})

@login_required
def book_activity(request, activity_id):
    activity = get_object_or_404(Activity, pk=activity_id)

    # 1) Check capacity
    if activity.spots_left() <= 0:
        messages.error(request, "No spots left for this activity.")
        return redirect('bookings:activity_list')

    # 2) Prevent more than one activity on the same date
    same_day = Booking.objects.filter(
        parent=request.user,
        activity__date=activity.date,
        cancelled=False
    )
    if same_day.exists():
        messages.error(request, "You already booked an activity on this date.")
        return redirect('bookings:activity_list')

    # 3) Prevent re-booking same activity if there is an ACTIVE booking
    existing = Booking.objects.filter(
        parent=request.user,
        activity=activity,
        cancelled=False
    )
    if existing.exists():
        messages.error(request, "You have already booked this activity.")
        return redirect('bookings:my_bookings')

    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.activity = activity
            booking.parent = request.user
            booking.save()
            messages.success(request, "Booking successful!")
            return redirect('bookings:my_bookings')
    else:
        form = BookingForm()

    return render(request, 'bookings/book_activity.html', {'activity': activity, 'form': form})

@login_required
def my_bookings(request):
    bookings = Booking.objects.filter(parent=request.user, cancelled=False).order_by('activity__date')
    return render(request, 'bookings/my_bookings.html', {'bookings': bookings})

@login_required
def cancel_booking(request, booking_id):
    booking = get_object_or_404(Booking, pk=booking_id, parent=request.user)
    if request.method == 'POST':
        booking.cancelled = True
        booking.save()
        messages.info(request, "Booking cancelled.")
        return redirect('bookings:my_bookings')
    return render(request, 'bookings/cancel_confirm.html', {'booking': booking})

@login_required
def invoice_view(request):
    bookings = Booking.objects.filter(parent=request.user, cancelled=False)
    total = sum([b.activity.price for b in bookings])
    return render(request, 'bookings/invoice.html', {'bookings': bookings, 'total': total})

@login_required
def invoice_pdf(request):
    bookings = Booking.objects.filter(parent=request.user, cancelled=False)
    total = sum([b.activity.price for b in bookings])

    # Set up HTTP response as a PDF file
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="invoice.pdf"'

    p = canvas.Canvas(response)
    y = 800  # start from top of the page

    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, y, "School Activity Booking - Invoice")
    y -= 30

    p.setFont("Helvetica", 12)
    p.drawString(50, y, f"Parent: {request.user.username}")
    y -= 20

    p.drawString(50, y, "Bookings:")
    y -= 20

    for b in bookings:
        line = f"{b.child_name} - {b.activity.title} - {b.activity.date} - {b.activity.price}"
        p.drawString(60, y, line)
        y -= 20
        if y < 50:
            p.showPage()
            y = 800
            p.setFont("Helvetica", 12)

    y -= 20
    p.setFont("Helvetica-Bold", 12)
    p.drawString(50, y, f"Total: {total}")

    p.showPage()
    p.save()
    return response
